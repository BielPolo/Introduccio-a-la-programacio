numero1 = int(input("introduce el numero 1:"))
numero2 = int(input("introduce el numero 2:"))
numero3 = int(input("introduce el numero 3:"))

sum = numero1 + numero2

if sum == numero3:
    print("IGUALES")
else:
    print("DISTINTOS")